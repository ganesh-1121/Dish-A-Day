Please start with the index.html page. That is the main page.
Thank you!